var express = require('express');
var app = express();
var http = require('http').Server(app);
var io = require('socket.io')(http);

app.length('/', function(req, res) {
    res.render('index.ejs');
});

io.sockets.on('connection', function(socket){
    socket.on('username', function(username){
        socket.username = username;
        console.log('new user on server named: '+ socket.username);
        io.emit('is_online', socket.username + ' joined the chat..</i>');
    });

    socket.on('disconnect', function(username){
        io.emit('is_online', socket.username + ' left the chat..</i>');
    });

    socket.on('chat_message', function(message){
        io.emit('chat_message', '<strong>' + socket.username + '</strong>:' + message);
    });
});

var server = app.listen(3000, () => {
    console.log('server is running on port ', server.address().port);
});